package testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Automation {

	//Create an global variable
	static WebDriver driver = new ChromeDriver();
	
	public static void main(String[] args) throws InterruptedException {

		openURL(); //open the website
		if(login() == true) { //if login is fail 
			forgotPassword();
		}else {
			
			
		}
	}

	
	public static void openURL() {		
		//open url
		driver.get("https://www.facebook.com/");

	}
	public static boolean login() throws InterruptedException {
		//find element and fill the login form
		driver.findElement(By.id("email")).sendKeys("vimlesh073@gmail.com");		
		driver.findElement(By.id("pass")).sendKeys("bafijfhh54");
		
		driver.findElement(By.name("login")).click();
		
		//waiting....
		Thread.sleep(5000); //1000 = 1 sec
		
		//get url 
		String url  = driver.getCurrentUrl();
		System.out.println(url);
				
		if(url.equals("https://www.facebook.com/login/")) 
			return true; //if login is failed
		else
			return false; //if login is success
	}
	
	public static void forgotPassword() {
		//read the text message 
		String msg = driver.findElement(By.xpath("//*[@id=\"globalContainer\"]/div[3]/div/div/div")).getText();
		System.out.println(msg);
		
		driver.findElement(By.xpath("//*[@id=\"login_link\"]/div/a")).click();
		
	}
	public static void resetPwd() {
		
	}
	public static void register() {
		
	}
	
}
