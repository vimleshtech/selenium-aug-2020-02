package testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Facebook {

	public static void main(String[] args) throws InterruptedException {
		
		//Create an object
		WebDriver driver = new ChromeDriver();
		
		//open url
		driver.get("https://www.facebook.com/");
		
		//find element and fill the login form
		driver.findElement(By.id("email")).sendKeys("vimlesh073@gmail.com");		
		driver.findElement(By.id("pass")).sendKeys("bafijfhh54");
		
		driver.findElement(By.name("login")).click();
		
		//waiting....
		Thread.sleep(5000); //1000 = 1 sec
		
		//get url 
		String url  = driver.getCurrentUrl();
		System.out.println(url);
		
		if(url.equals("https://www.facebook.com/login/")) {
			System.out.println("in condition");
		
			//read the text message 
			String msg = driver.findElement(By.xpath("//*[@id=\"globalContainer\"]/div[3]/div/div/div")).getText();
			System.out.println(msg);
			
			driver.findElement(By.xpath("//*[@id=\"login_link\"]/div/a")).click();
			
			
		}		
		
		//
				
		
	}

}
